using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Linq;
using iTextSharp.text.pdf;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using Microsoft.Office.Interop.Word;

namespace MergePDFs
{
    public static class MergePDFDocuments
    {
        [FunctionName("MergePDFDocuments"), RequestFormLimits(ValueLengthLimit = int.MaxValue, MultipartBodyLengthLimit = int.MaxValue)]
        public static async Task<IActionResult> RunMerge([HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req, ILogger log)
        {
            try
            {
                // Initialise Variables
                string tempFilePath = Path.GetTempPath();
                // Clean up Temp Folder before starting
                foreach (var tempfiles in Directory.GetFiles(tempFilePath))
                {
                    File.Delete(tempfiles);
                }
                //Check if correct content type
                if (!req.ContentType.StartsWith("multipart/form-data", StringComparison.OrdinalIgnoreCase))
                {
                    return new BadRequestObjectResult("Incorrect content type. Expected 'multipart/form-data'.");
                }
                //Check if files attached
                if (!req.Form.Files.Any() || req.Form.Files == null || req.Form.Files.Count == 0)
                {
                    return new BadRequestObjectResult("No files were uploaded");
                }
                // Get Files
                var files = req.Form.Files;
                //Set output filename
                var outputfilename = $"{tempFilePath}{Guid.NewGuid()}.pdf";
                using (FileStream fstream = new FileStream(outputfilename, FileMode.Create))
                {
                    //Create new empty document
                    using (iTextSharp.text.Document document = new iTextSharp.text.Document(iTextSharp.text.PageSize.A4, 10f, 10f, 10f, 0f))
                    {                        
                        PdfCopy pdf = new PdfCopy(document, fstream);
                        document.Open();
                        foreach (var file in files)
                        {
                            //Open file in read stream and save as temp file
                            using (Stream stream = file.OpenReadStream())
                            {
                                SaveStreamAsFile(tempFilePath, stream, file.FileName);
                            }
                            //Open file with reader
                            using (PdfReader reader = new PdfReader(Path.Combine(tempFilePath, file.FileName)))
                            {
                                //Add reader contents to pdf
                                pdf.AddDocument(reader);
                            }
                        }                        
                    }
                }
                //Create a new output file stream
                FileStream fStream = new FileStream(outputfilename, FileMode.Open);
                //Return the file stream
                return new OkObjectResult(fStream);
            }
            catch(Exception ex)
            {
                return LogErrorMessage(ex, log);
            }
        }

        [FunctionName("ConvertDocumentToPdf"), RequestFormLimits(ValueLengthLimit = int.MaxValue, MultipartBodyLengthLimit = int.MaxValue)]
        public static async Task<IActionResult> RunConvert([HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req, ILogger log)
        {
            try
            {
                // Initialise Variables
                string tempFilePath = Path.GetTempPath();
                // Clean up Temp Folder before starting
                //foreach (var tempfiles in Directory.GetFiles(tempFilePath))
                //{
                //    File.Delete(tempfiles);
                //}
                //Check if correct content type
                if (!req.ContentType.StartsWith("multipart/form-data", StringComparison.OrdinalIgnoreCase))
                {
                    return new BadRequestObjectResult("Incorrect content type. Expected 'multipart/form-data'.");
                }
                //Check if files attached
                if (!req.Form.Files.Any() || req.Form.Files == null || req.Form.Files.Count == 0)
                {
                    return new BadRequestObjectResult("No files were uploaded");
                }
                // Get Files
                var file = req.Form.Files[0];
                if (!file.FileName.Contains(".doc", StringComparison.OrdinalIgnoreCase) && !file.FileName.Contains(".xls", StringComparison.OrdinalIgnoreCase))
                {
                    return new BadRequestObjectResult("Incorrect file type. Expected '.docx' or '.xlsx'.");
                }
                //Set output filename
                var outputfilename = $"{tempFilePath}{file.FileName.Substring(0,file.FileName.Length-5)}.pdf";
                using (FileStream fstream = new FileStream(outputfilename, FileMode.Create))
                {
                    //Open file in read stream and save as temp file
                    using (Stream stream = file.OpenReadStream())
                    {
                        SaveStreamAsFile(tempFilePath, stream, file.FileName);
                    }
                }
                //Convert docx to pdf
                ConvertDocumentToPdf(Path.Combine(tempFilePath, file.FileName),tempFilePath);
                //Create a new output file stream
                FileStream fStream = new FileStream(outputfilename, FileMode.Open);
                //Return the file stream
                return new OkObjectResult(fStream);
            }
            catch (Exception ex)
            {
                return LogErrorMessage(ex, log);
            }
        }        
        //Helper method to save file back to file stream
        private static void SaveStreamAsFile(string filePath, Stream inputStream, string fileName)
        {
            DirectoryInfo info = new DirectoryInfo(filePath);
            if (!info.Exists)
            {
                info.Create();
            }
            string path = System.IO.Path.Combine(filePath, fileName);
            using (FileStream outputFileStream = new FileStream(path, FileMode.Create))
            {
                inputStream.CopyTo(outputFileStream);
            }
        }
        private static BadRequestObjectResult LogErrorMessage(Exception ex,ILogger log)
        {
            string errorMessages = $"Index #1\nMessage: {ex.Message}\nStack Trace: {ex.StackTrace}\nSource: {ex.Source}\nTarget Site: {ex.TargetSite}";
            log.LogError(errorMessages);
            return new BadRequestObjectResult(errorMessages);
        }
        public static void ConvertDocumentToPdf(string docxFilePath, string pdfFilePath)
        {
            // Create LibreOfficeWriter CLI process
            var commandArgs = new List<string>
            {
                "--convert-to", //a flag that will be followed by the file type we want to convert to
                "pdf:writer_pdf_Export", // the [output file type]:[OutputFilterName] we are requesting the output to be; more details are here (https://help.libreoffice.org/latest/en-US/text/shared/guide/convertfilters.html)
                docxFilePath, // input file
                "--norestore", // disables restart and file recovery after a system crash
                "--headless", // allows using the application without user interface
                "--outdir", // a flag that will be followed by the output directory where we want our new pdf file to be created
                pdfFilePath // output directory
            };

            // The path to LibreOfficeWriterPortable.exe
            ProcessStartInfo processStartInfo = new ProcessStartInfo(Environment.GetEnvironmentVariable("HOME") + @"\site\wwwroot\LibreOfficePortable\LibreOfficePortable.exe");
            foreach (string arg in commandArgs)
                processStartInfo.ArgumentList.Add(arg);

            Process process = new Process
            {
                StartInfo = processStartInfo
            };

            // Only 1 instance of LibreOfficeWriter can be running at a given time
            Process[] existingProcesses = Process.GetProcessesByName("soffice");
            while (existingProcesses.Length > 0)
            {
                Thread.Sleep(1000);
                existingProcesses = Process.GetProcessesByName("soffice");
            }

            // Start the process
            process.Start();
            process.WaitForExit();

            // Check for failed exit code.
            if (process.ExitCode != 0)
                throw new Exception("Failed to convert file");
            else
            {
                int totalChecks = 10;
                int currentCheck = 1;

                string originalFileName = Path.GetFileNameWithoutExtension(commandArgs[2]);
                string newFilePath = Path.Combine(commandArgs[6], $"{originalFileName}.pdf");

                while (currentCheck <= totalChecks)
                {
                    if (File.Exists(newFilePath))
                    {
                        // File conversion was successful

                        break;
                    }

                    Thread.Sleep(500); // LibreOffice doesn't immediately create PDF output once the command is run
                }
            }
        }
        public static void ConvertDocxToPdf(string docxFilePath, string pdfFilePath)
        {
            Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
            object oMissing = System.Reflection.Missing.Value;
            FileInfo wordFile = new FileInfo(docxFilePath);
            word.Visible = false;
            word.ScreenUpdating = false;
            Object filename = (Object)wordFile.FullName;
            Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename);
            object fileFormat = WdSaveFormat.wdFormatPDF;
            doc.SaveAs2(pdfFilePath, fileFormat);
            doc.Close(WdSaveOptions.wdSaveChanges);
            word.Quit();
        }
    }
}
